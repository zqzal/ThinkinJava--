//: innerclasses/Destination.java
public interface Destination {
  String readLabel();
} ///:~
