//: innerclasses/Contents.java
public interface Contents {
  int value();
} ///:~
